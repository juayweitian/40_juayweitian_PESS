<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
.fade-in-text {
  display: inline-block;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 15px;
  color: black;
  animation: fadeIn linear 2s;
  -webkit-animation: fadeIn linear 2s;
  -moz-animation: fadeIn linear 2s;
  -o-animation: fadeIn linear 2s;
  -ms-animation: fadeIn linear 2s;
}

@keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-moz-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-webkit-keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-o-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-ms-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}
ul {
  list-style-type: none;
  margin: 0px;
  padding: 0px;
  overflow: hidden;
  border: 1px solid #e7e7e7;
  background-color: #0d0d0d;

}

li {
  float: left;
 width:25%;


}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 167px;
  text-decoration: none;
  
}

li a:hover {
  background-color: #006600;
  color:white;
  
}

li a:hover:not(.active) {
  background-color: #black;

}

li a.active {
  color: white;
  background-color: #006600;
width:14%;
}

img {
width:100%;

}


</style>
</head>

<body>
<div class="fade-in-text">
<center>
<img src="image/banner.gif">
</center>


<ul>
  <li><a class="active" href="logcall.php">LogCall</a></li>
  <li><a href="update.php">Update</a></li>
  <li><a href="report.php">Report</a></li>
  <li><a href="history.php">History</a></li>
</ul>
</div>
</body>

</html>
