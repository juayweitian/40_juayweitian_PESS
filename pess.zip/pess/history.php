<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1.0">
<title>Police Emergency Service System</title>

<?php

$conn = mysqli_connect('localhost','root','','pessdb');

$sql = "SELECT * FROM dispatch";

$result = mysqli_query($conn,$sql);

?>
<style>
ul {
  list-style-type: none;
  margin: 0px;
  padding: 0px;
  overflow: hidden;
  border: 1px solid #e7e7e7;
  background-color: #0d0d0d;
}

li {
  float: left;
 width:25%;


}

th {
border: 1px solid white;
}
li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 168px;
  text-decoration: none;
 
}

li a:hover {
  background-color: #006600;
  color:white;
  
}

li a:hover:not(.active) {
  background-color: #black;

}

li a.active {
  color: white;
  background-color: #006600;
width:16%;
}

tr {
background-color: #0d0d0d;
color:white;
font-family:verdana;

}

td {

border:1px solid white;
padding:10px;

}

table {

padding:40px;
width:100%;
}

body {

background-image: url(image/background2.jpg);
	background-position:center;
	background-size:cover;
	background-attachment:fixed;
	align-items:center;
	margin:0;
        padding:0;

}

.fade-in-text {
  display: inline-block;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 15px;
  color: black;
  animation: fadeIn linear 2s;
  -webkit-animation: fadeIn linear 2s;
  -moz-animation: fadeIn linear 2s;
  -o-animation: fadeIn linear 2s;
  -ms-animation: fadeIn linear 2s;
}

@keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-moz-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-webkit-keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-o-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-ms-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

tr {


}
</style>
</head>

<body>
<div class="fade-in-text">
<center>
<img src="image/banner.gif" width=100%>
</center>

<ul>
  <li><a href="logcall.php">LogCall</a></li>
  <li><a href="update.php">Update</a></li>
  <li><a href="report.php">Report</a></li>
  <li><a class="active" href="history.php">History</a></li>
</ul>

<table>
<tr>

<th>
incidentId
</th>

<th>
patrolcarId
</th>

<th>
timeDispatched
</th>

<th>
timeArrived
</th>

<th>
timeCompleted
</th>


</tr>

<?php while($row = mysqli_fetch_array($result)){ ?>

     <tr>
         <td><?php echo $row['incidentId'];?></td>
         <td><?php echo $row['patrolcarId'];?></td>
         <td><?php echo $row['timeDispatched'];?></td>
         <td><?php echo $row['timeArrived'];?></td>
         <td><?php echo $row['timeCompleted'];?></td>
     </tr>

<?php } ?>
</table>

</div>
</body>


</html>