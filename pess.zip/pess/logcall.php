<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1.0">
<title>Police Emergency Service System</title>
<style>
.fade-in-text {
  display: inline-block;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 15px;
  color: black;
  animation: fadeIn linear 3s;
  -webkit-animation: fadeIn linear 2s;
  -moz-animation: fadeIn linear 2s;
  -o-animation: fadeIn linear 2s;
  -ms-animation: fadeIn linear 2s;
}

@keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-moz-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-webkit-keyframes fadeIn{
  0% {opacity:0;}
  100% {opacity:1;}
}

@-o-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-ms-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}
tr {
background-color: #0d0d0d;
color:white;
font-family:verdana;

}

td {

border:1px solid white;
padding:10px;

}

body {

background-image: url(image/background2.jpg);
	background-position:center;
	background-size:cover;
	background-attachment:fixed;
	align-items:center;
	margin:0;
        padding:0;

}

form {

margin-top:50px;
z-index:3;
}

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-family:verdana;
  border-radius:25px;
}

input[type=submit] {
  width: 100%;
  background-color: #006600;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 25px;
  cursor: pointer;
  font-size:15px;
  font-family:verdana;
}

input[type=reset] {
  width: 100%;
  background-color: #006600;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 25px;
  cursor: pointer;
  font-size:15px;
}

.color-overlay {
	width:100%;
	height:100%;
	background:#000;
	opacity: .8;
	position: absolute;
        z-index:1;
}

.front {
z-index:3;
position:relative;
}
</style>
</head>
<body> 
 <script> 
  function juayweitian() 
  { 
   var x=document.forms["frmLogCall"]["callerName"].value; 
   if (x==null || x=="") 
     
   { 
    alert("Caller Name is required."); 
    return false; 
   } 
    
  } 
  
 
 </script> 
  
  
  
<?php // import nav.php 
 require_once 'nav.php'; 
?> 
  
<?php // import db.php 
 require_once 'db.php'; 
  
// Create connection 
 $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE ); 
 // check connection 
 if ($mysqli->connect_errno)  
 { 
  die("Unable to connect to Database: " .$mysqli->connect_errno); 
 } 
  
 $sql = "SELECT * FROM incidenttype"; 
  
 if(!($stmt = $mysqli->prepare($sql))) 
 { 
  die("command error: ".$mysqli->errno); 
 } 
  
 if (!$stmt->execute()) 
   
 { 
  die("cannot run SQL command: ".$stmt->errno); 
 } 
  
 if(!($resultset = $stmt->get_result())) { 
 die("No data in resultset: ".stmt->errno); 
 } 
  
 $incidentType; 
  
 while ($row = $resultset->fetch_assoc()) { 
   
$incidentType[$row['incidentTypeId']] = $row['incidentTypeDesc']; 
 } 
  
 $stmt->close(); 
  
 $resultset->close(); 
  
 $mysqli->close(); 
  
?> 
  
  

 <div class="fade-in-text">
  <div class="color-overlay"></div>
<div class="front">
 <form name="frmLogCall" method="post" action="dispatch.php" onSubmit="return juayweitian();">
 <table width="40%"  align="center" cellpadding="4" cellspacing="4"> 
   
   
 <tr> 
 <td width="80%">Caller's Name :</td> 
 <td width="50%"><input type="text" name="callerName" id="callerName"></td> 
 </tr> 
   
 <tr> 
 <td width="50%">Contact No :</td> 
 <td><input type="text" name="contactNo" id="contactNo"></td> 
 </tr> 
   
<tr> 
 <td width="50%">Location :</td> 
 <td><input type="text" name="location" id="location"></td> 
 </tr> 
   
 <td width="50%">Incident Type :</td>
        <td><select name="incidentType" id="incidentType"> <?php foreach($incidentType as $key=> $value) {?>
        <option value="<?php echo $key?>" > <?php echo $value ?>
        </option>
            <?php } ?>
    </select>
    </td>
 </tr> 
   
 <td width="50%">Description :</td> 
  <td width="50%"><textarea name="incidentDesc" id="incidentDesc" cols="45" rows="5"></textarea> 
 </td> 
 </tr> 
<tr> 
  <td><input type="reset" name="cancelProcess" id="cancelProcess" value="Reset"> 
 </td> 
  
  <td><input type="submit" name="btnProcessCall" id="btnProcessCall" value="Process Call"></td> 
 </tr> 

 </form>
</div>
</div>
</body> 
</html>